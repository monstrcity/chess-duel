const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const { Chess } = require("chess.js");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
    cors: {
        origin: "*"
    }
});

const PORT = process.env.PORT || 3000;

const rooms = new Map();

app.use(express.static("public"));

app.get("/health", (req, res) => {
    res.json({
        status: "online",
        game: "CHESS DUEL",
        rooms: rooms.size
    });
});

// إنشاء رمز الغرفة
function generateCode() {
    return crypto.randomBytes(3)
        .toString("hex")
        .toUpperCase();
}

// تنظيف الاسم
function cleanName(name) {
    return String(name || "Player")
        .trim()
        .replace(/[<>]/g, "")
        .slice(0, 20) || "Player";
}

// الحصول على لون اللاعب
function getPlayerColor(room, socket) {

    if (room.players.w?.id === socket.id) {
        return "w";
    }

    if (room.players.b?.id === socket.id) {
        return "b";
    }

    return null;
}

// التحقق من وجود لاعبين
function isFull(room) {
    return !!(room.players.w && room.players.b);
}

// حالة الغرفة
function getRoomState(room) {

    return {

        code: room.code,

        fen: room.game.fen(),

        pgn: room.game.pgn(),

        turn: room.game.turn(),

        players: {

            w: room.players.w?.name || null,

            b: room.players.b?.name || null

        },

        status: room.game.isGameOver()
            ? room.game.isCheckmate()
                ? "checkmate"
                : "draw"
            : room.game.isCheck()
                ? "check"
                : "playing"

    };

}

// إرسال حالة المباراة
function updateRoom(room) {

    io.to(room.code).emit(
        "game:state",
        getRoomState(room)
    );

}

// إرسال خطأ
function sendError(callback, message) {

    if (typeof callback === "function") {

        callback({
            ok: false,
            error: message
        });

    }

}

// حذف الغرفة
function deleteRoom(code) {

    const room = rooms.get(code);

    if (!room) return;

    clearTimeout(room.deleteTimer);

    rooms.delete(code);

    console.log("Room deleted:", code);

}

// الاتصال
io.on("connection", (socket) => {

    console.log("Connected:", socket.id);

    // إنشاء غرفة
    socket.on("room:create", (data = {}, callback = () => {}) => {

        let code;

        do {
            code = generateCode();
        } while (rooms.has(code));

        const room = {

            code,

            game: new Chess(),

            players: {

                w: {
                    id: socket.id,
                    name: cleanName(data.name)
                },

                b: null

            },

            drawOffer: null,

            undoOffer: null,

            finished: false,

            deleteTimer: null

        };

        rooms.set(code, room);

        socket.join(code);

        socket.data.room = code;

        callback({

            ok: true,

            color: "w",

            state: getRoomState(room)

        });

        updateRoom(room);

        console.log("Room created:", code);

    });

    // الانضمام
    socket.on("room:join", (data = {}, callback = () => {}) => {

        const code = String(data.code || "")
            .trim()
            .toUpperCase();

        const room = rooms.get(code);

        if (!room) {
            return sendError(callback, "الغرفة غير موجودة.");
        }

        if (room.finished) {
            return sendError(callback, "هذه المباراة انتهت.");
        }

        if (room.players.b) {
            return sendError(callback, "الغرفة مكتملة.");
        }

        room.players.b = {

            id: socket.id,

            name: cleanName(data.name)

        };

        clearTimeout(room.deleteTimer);

        socket.join(code);

        socket.data.room = code;

        callback({

            ok: true,

            color: "b",

            state: getRoomState(room)

        });

        updateRoom(room);

        console.log("Player joined:", code);

    });

    // النقلات
    socket.on("move", (data = {}, callback = () => {}) => {

        const room = rooms.get(socket.data.room);

        if (!room) {
            return sendError(callback, "لا توجد مباراة.");
        }

        const color = getPlayerColor(room, socket);

        if (!color) {
            return sendError(callback, "أنت لست لاعباً في هذه الغرفة.");
        }

        if (!isFull(room)) {
            return sendError(callback, "بانتظار اللاعب الثاني.");
        }

        if (room.finished || room.game.isGameOver()) {
            return sendError(callback, "انتهت المباراة.");
        }

        if (room.game.turn() !== color) {
            return sendError(callback, "ليس دورك.");
        }

        try {

            const result = room.game.move({

                from: data.from,

                to: data.to,

                promotion: data.promotion || "q"

            });

            if (!result) {
                return sendError(callback, "نقلة غير قانونية.");
            }

            room.drawOffer = null;

            room.undoOffer = null;

            callback({
                ok: true
            });

            updateRoom(room);

            // إنهاء المباراة عند الكش مات أو التعادل
            if (room.game.isGameOver()) {

                room.finished = true;

                io.to(room.code).emit("game:finished", {

                    result: room.game.isCheckmate()
                        ? "checkmate"
                        : "draw",

                    winner: room.game.isCheckmate()
                        ? color
                        : null

                });

            }

        } catch (error) {

            sendError(callback, "النقلة غير صالحة.");

        }

    });

    // الدردشة
    socket.on("chat", (data = {}) => {

        const room = rooms.get(socket.data.room);

        if (!room) return;

        const color = getPlayerColor(room, socket);

        if (!color) return;

        const message = String(data.text || "")
            .trim()
            .slice(0, 180);

        if (!message) return;

        io.to(room.code).emit("chat", {

            name: room.players[color].name,

            text: message,

            time: Date.now()

        });

    });

    // طلب التعادل
    socket.on("offer:draw", () => {

        const room = rooms.get(socket.data.room);

        if (!room || room.finished) return;

        const color = getPlayerColor(room, socket);

        if (!color || !isFull(room)) return;

        if (room.game.isGameOver()) return;

        room.drawOffer = color;

        socket.to(room.code).emit("offer:draw", {

            from: color

        });

    });

    // الرد على التعادل
    socket.on("respond:draw", (data = {}) => {

        const room = rooms.get(socket.data.room);

        if (!room || !room.drawOffer) return;

        const color = getPlayerColor(room, socket);

        if (!color) return;

        // منع صاحب الطلب من الرد على طلبه
        if (color === room.drawOffer) return;

        if (data.accept) {

            room.finished = true;

            io.to(room.code).emit("game:finished", {

                result: "draw-agreed",

                winner: null

            });

        } else {

            room.drawOffer = null;

            io.to(room.code).emit("offer:declined", {

                type: "draw"

            });

        }

    });

    // طلب التراجع
    socket.on("offer:undo", () => {

        const room = rooms.get(socket.data.room);

        if (!room || room.finished) return;

        const color = getPlayerColor(room, socket);

        if (!color || !isFull(room)) return;

        if (!room.game.history().length) return;

        room.undoOffer = color;

        socket.to(room.code).emit("offer:undo", {

            from: color

        });

    });

    // الرد على التراجع
    socket.on("respond:undo", (data = {}) => {

        const room = rooms.get(socket.data.room);

        if (!room || !room.undoOffer) return;

        const color = getPlayerColor(room, socket);

        if (!color) return;

        // منع صاحب الطلب من قبول طلبه
        if (color === room.undoOffer) return;

        if (data.accept) {

            room.game.undo();

            room.undoOffer = null;

            room.drawOffer = null;

            updateRoom(room);

        } else {

            room.undoOffer = null;

            io.to(room.code).emit("offer:declined", {

                type: "undo"

            });

        }

    });

    // الاستسلام
    socket.on("resign", () => {

        const room = rooms.get(socket.data.room);

        if (!room || room.finished) return;

        const color = getPlayerColor(room, socket);

        if (!color) return;

        if (room.game.isGameOver()) return;

        room.finished = true;

        io.to(room.code).emit("game:finished", {

            result: "resign",

            winner: color === "w" ? "b" : "w"

        });

    });

    // مغادرة الغرفة
    socket.on("room:leave", () => {

        leaveRoom(socket);

    });

    // مغادرة اللاعب
    function leaveRoom(socket) {

        const code = socket.data.room;

        if (!code) return;

        const room = rooms.get(code);

        if (!room) return;

        const color = getPlayerColor(room, socket);

        if (color) {

            room.players[color] = null;

        }

        socket.leave(code);

        socket.data.room = null;

        io.to(code).emit("player:disconnected", {

            message: "غادر أحد اللاعبين المباراة."

        });

        // حذف الغرفة بعد دقيقة إذا لم يعد اللاعب
        if (!room.players.w && !room.players.b) {

            deleteRoom(code);

        } else {

            room.deleteTimer = setTimeout(() => {

                if (!room.players.w && !room.players.b) {

                    deleteRoom(code);

                }

            }, 60000);

        }

    }

    // انقطاع الاتصال
    socket.on("disconnect", () => {

        console.log("Disconnected:", socket.id);

        leaveRoom(socket);

    });

});

// تنظيف الغرف القديمة
setInterval(() => {

    for (const [code, room] of rooms) {

        if (!room.players.w && !room.players.b) {

            deleteRoom(code);

        }

    }

}, 300000);

// تشغيل الخادم
server.listen(PORT, () => {

    console.log("--------------------------------");

    console.log("CHESS DUEL SERVER RUNNING");

    console.log("PORT:", PORT);

    console.log("--------------------------------");

});